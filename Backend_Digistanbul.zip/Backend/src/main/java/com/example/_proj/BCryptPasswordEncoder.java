package com.example._proj;

public class BCryptPasswordEncoder {

}
